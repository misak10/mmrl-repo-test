
########################
example configuration / documentation
########################

[sing-box documentation](http://sing-box.sagernet.org/configuration)