SKIPUNZIP=0
sh $MODPATH/script/setup.sh
[ "$?" != "0" ] && abort
