## 更新日志:

### 版本号：内存优化 2025-02-28

- 自动设置 ZRAM 大小为物理内存 +1。
- Author: 焕晨HChen

## Update Info:

### Version: MemoryOpt v.2025-02-28

- Automatically set ZRAM size to physical memory +1.
- Author: 焕晨HChen
